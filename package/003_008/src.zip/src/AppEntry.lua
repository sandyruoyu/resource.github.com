--游戏启动入口
require("Game")
game.preload()
game.startup()

